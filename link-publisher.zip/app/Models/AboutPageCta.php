<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AboutPageCta extends Model
{
    protected $guarded = ['id'];
}
