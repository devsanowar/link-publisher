<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BuildBacklink extends Model
{
    protected $guarded = ['id'];
}
