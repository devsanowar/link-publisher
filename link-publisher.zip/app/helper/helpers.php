<?php
// if (!function_exists('getSvgIcon')) {
//     function getSvgIcon($name)
//     {
//         $icons = [
//             'guest-posting' => '<svg xmlns="http://www.w3.org/2000/svg" ...>...</svg>',
//             'link-building' => '<svg xmlns="http://www.w3.org/2000/svg" ...>...</svg>',
//             'digital-pr' => '<svg xmlns="http://www.w3.org/2000/svg" ...>...</svg>',
//             'niche-edits' => '<svg xmlns="http://www.w3.org/2000/svg" ...>...</svg>',
//         ];

//         return $icons[$name] ?? '';
//     }
// }
